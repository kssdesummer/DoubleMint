# 2019-09-05 个人分享内容

1. 冒泡
2. 默认事件





## 冒泡

事件冒泡阶段：

事件从事件目标(target)开始，往上冒泡直到页面的最上一级标签。

假设一个元素div，它有一个下级元素p。
```html
<div>
　　<p>元素</p>
</div>
```



这两个元素都绑定了click事件，如果用户点击了p，它在div和p上都触发了click事件，那这两个事件处理程序哪个先执行呢？事件顺序是什么？

两种模型

以前，Netscape和Microsoft是不同的实现方式。

Netscape中，div先触发，这就叫做事件捕获。
Microsoft中，p先触发，这就叫做事件冒泡。



Netscape 与 Microsoft 是竞争对手



两种事件处理顺序刚好相反。

IE只支持事件冒泡，Mozilla, Opera 7 和 Konqueror两种都支持，旧版本的Opera's 和 iCab两种都不支持 。



事件捕获
当你使用事件捕获时，父级元素先触发，子级元素后触发，即div先触发，p后触发。



事件冒泡
当你使用事件冒泡时，子级元素先触发，父级元素后触发，即p先触发，div后触发。





### 防止冒泡

**w3c的方法是e.stopPropagation()，IE则是使用e.cancelBubble = true**



## 默认行为

很多的网页元素都会有默认的行为，比如说当你点击一下超链接**a标签**的时候，它会有一个跳转的行为；当你在网页上点**鼠标右键**时会出现一个**右键菜**；当你在一个form表单里点击**提交按钮**时网页会产生提交行为并刷新网页，当你网页上**滚动鼠标滚轮**时，网页的滚动条会动等等。这些都叫事件的默认行为





**w3c的方法是e.preventDefault()，IE则是使用e.returnValue = false;**





preventDefault它是事件对象(Event)的一个方法，作用是取消一个目标元素的默认行为。



既然是说默认行为，当然是元素必须有默认行为才能被取消，如果元素本身就没有默认行为，调用当然就无效了。





什么元素有默认行为呢？

如链接<a>，提交按钮<input type="submit">等。



当Event 对象的 **cancelable**为false时，表示没有默认行为，这时即使有默认行为，调用preventDefault也是不会起作用的。





### 总结使用方法

当需要停止冒泡行为时，可以使用

```
function stopBubble(e) { 
//如果提供了事件对象，则这是一个非IE浏览器 
if ( e && e.stopPropagation ) 
    //因此它支持W3C的stopPropagation()方法 
    e.stopPropagation(); 
else 
    //否则，我们需要使用IE的方式来取消事件冒泡 
    window.event.cancelBubble = true; 
}
```

当需要阻止默认行为时，可以使用[·](http://caibaojian.com/javascript-stoppropagation-preventdefault.html)

```
//code from http://caibaojian.com/javascript-stoppropagation-preventdefault.html
//阻止浏览器的默认行为 
function stopDefault( e ) { 
    //阻止默认浏览器动作(W3C) 
    if ( e && e.preventDefault ) 
        e.preventDefault(); 
    //IE中阻止函数器默认动作的方式 
    else 
        window.event.returnValue = false; 
    return false; 
}
```



### 事件注意点

1. 1. event代表事件的状态，例如触发event对象的元素、鼠标的位置及状态、按下的键等等；
   2. event对象只在事件发生的过程中才有效。

firefox里的event跟IE里的不同，IE里的是全局变量，随时可用；firefox里的要用参数引导才能用，是运行时的临时变量。
在IE/Opera中是window.event，在Firefox中是event；而事件的对象，在IE中是window.event.srcElement，在Firefox中是event.target，Opera中两者都可用。[·](http://caibaojian.com/javascript-stoppropagation-preventdefault.html)

1. 1. 下面两句效果相同：

```
//code from http://caibaojian.com/javascript-stoppropagation-preventdefault.html
function a(e){
var e = (e) ? e : ((window.event) ? window.event : null); 
var e = e || window.event; // firefox下window.event为null, IE下event为null
}
```





具体的来源地址:http://caibaojian.com/javascript-stoppropagation-preventdefault.html



